x = float(input("Digite um numero: "))
y = float(input("Digite outro numero: "))
soma = x+y
print("A soma de x + y é: " + str(soma))