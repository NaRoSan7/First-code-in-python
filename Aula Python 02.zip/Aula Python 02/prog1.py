print("\n\n");


# Crie um Programa que apresenta o valor do produto com desconto

produto = 100; # Valor do produto
desconto = 0.1; #Desconto de 10%
vf = produto - desconto * 100;

print("Valor do produto: " + str(produto));
print("Desconto aplicado: " + str(desconto));
print("Valor final da compra: " + str(vf));

#Conceito de juros

emprestimo = 500;
juros = 0.02;
valorfinal = emprestimo*juros;

print("Valor do Emprestimo: " + str(emprestimo));
print("Valor do Juros : " + str(juros));
print("Valor Final:" + str(valorfinal));

print("\n\n");